This module allows to manage a hierarchy of equipments.
